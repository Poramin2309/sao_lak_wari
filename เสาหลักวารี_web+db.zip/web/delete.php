<?php require "connection.php"; ?>
<?php
    $ID = $_GET["ItemID"];
    $Name = $_GET["ItemTypeName"];
    $stmt = $pdo->prepare("DELETE FROM item WHERE itemID = ?");
    $stmt->bindParam(1,$ID);
    if($stmt->execute()){
        header("location: detail.php?ItemTypeName=" . $Name);
    }
?>