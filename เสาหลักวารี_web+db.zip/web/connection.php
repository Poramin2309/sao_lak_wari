<?php 
    $pdo = new PDO("mysql:host=10.199.66.227; dbname=20s2_g5_saolakwari;charset=utf8","20S2_g5","TrW9kamM");
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
?>