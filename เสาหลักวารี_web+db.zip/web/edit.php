<?php require "connection.php"; ?>
<!DOCTYPE html>
<html>
<head>
  <style>
    .from-center{
      margin-left:500px
     }
     .from-center2{
      margin-top:100px
     }
     .fontsize{
       font-size:20px
     }
  </style>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Admin/AddItem</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="plugins/fontawesome-free/css/all.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <!-- Tempusdominus Bbootstrap 4 -->
  <link rel="stylesheet" href="plugins/tempusdominus-bootstrap-4/css/tempusdominus-bootstrap-4.min.css">
  <!-- iCheck -->
  <link rel="stylesheet" href="plugins/icheck-bootstrap/icheck-bootstrap.min.css">
  <!-- JQVMap -->
  <link rel="stylesheet" href="plugins/jqvmap/jqvmap.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/adminlte.min.css">
  <!-- overlayScrollbars -->
  <link rel="stylesheet" href="plugins/overlayScrollbars/css/OverlayScrollbars.min.css">
  <!-- Daterange picker -->
  <link rel="stylesheet" href="plugins/daterangepicker/daterangepicker.css">
  <!-- summernote -->
  <link rel="stylesheet" href="plugins/summernote/summernote-bs4.css">
  <!-- Google Font: Source Sans Pro -->
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
</head>
<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper">

  <!-- Navbar -->
  <nav class="main-header navbar navbar-expand navbar-white navbar-light">
    <!-- Left navbar links -->
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" data-widget="pushmenu" href="#"><i class="fas fa-bars"></i></a>
      </li> 
    </ul>
  </nav>
  <!-- /.navbar -->

  <!-- Main Sidebar Container -->
  <aside class="main-sidebar sidebar-dark-primary elevation-4">
    <!-- Brand Logo -->
    <a href="index.php" class="brand-link">
      <img src="dist/img/AdminLTELogo.png" alt="AdminLTE Logo" class="brand-image img-circle elevation-3"
           style="opacity: .8">
      <span class="brand-text font-weight-light">Admin cs kku</span>
    </a>

    <!-- Sidebar -->
    <div class="sidebar">
      <!-- Sidebar user panel (optional) -->
      <div class="user-panel mt-3 pb-3 mb-3 d-flex">
        <div class="image">
          <img src="dist/img/user2-160x160.jpg" class="img-circle elevation-2" alt="User Image">
        </div>
        <div class="info">
          <a href="#" class="d-block">เสาหลักวารี</a>
        </div>
      </div>

      <!-- Sidebar Menu -->
      <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
          <!-- Add icons to the links using the .nav-icon class
               with font-awesome or any other icon font library -->
          <li class="nav-item has-treeview menu-open">
            <a href="#" class="nav-link active">
              <i class="nav-icon fas fa-th"></i>
              <p>
                Menu
                
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="./index.php" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Home</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="./additem.php" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Add Item</p>
                </a>
              </li>
              
            </ul>
          </li>
        </ul>
      </nav>
      <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
  </aside>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">แก้ไขรายการครุภัณฑ์</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">รายการครุภัณฑ์</a></li>
              <li class="breadcrumb-item active">แก้ไขรายการครุภัณฑ์</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
        <div class="from-center from-center2 fontsize">
            <?php
            require "connection.php";

            if(isset($_GET['ItemID'])){
                $id = $_GET['ItemID'];
                $stmt1 = $pdo->prepare("SELECT * FROM Item,ItemDetail,ItemType 
                                        WHERE Item.ItemDetailID = ItemDetail.ItemDetailID 
                                        AND ItemDetail.ItemTypeID = ItemType.ItemTypeID
                                        AND ItemID = '$id'");
                $stmt1->execute();
                $row = $stmt1->fetch();
            }
            ?>
            <form method="post">
                <label for="ItemDetailID">ชื่อครุภัณฑ์   : <?php echo $row['ItemDetailName']; ?></label>
                <br>
                <label for="ItemID">รหัสครุภัณฑ์    : <?php echo $row['ItemID']; ?></label>
                <input type="hidden" value="<?php echo $row['ItemID']; ?>" name="ItemID" id="ItemID">
                <input type="hidden" value="<?php echo $row['ItemTypeName']; ?>" name="ItemTypeName" id="ItemTypeName"><br>
                <label for="Location">ที่อยู่ครุภัณฑ์    : </label>
                <input type="text" name="Location" id="Location"><br>
                <label for="Status">สถานะครุภัณฑ์    : </label>
                <select name="Status">
                    <option value=''>กรุณาเลือกสถานะ</option>
                    <option value='พร้อมใช้งาน'>พร้อมใช้งาน</option>
                    <option value='ส่งซ่อม'>ส่งซ่อม</option>
                    <option value='ถูกยืม'>ถูกยืม</option>
                </select>

                <br>
                <button type="submit" name="btn-submit" id="btn-submit"><strong>ยืนยัน</strong></button>
            </form>
	<?php
	    if (isset($_POST['btn-submit'])) {    
            if($_POST['Location'] == ''){
                echo "กรุณาใส่ที่อยู่ครุภัณฑ์";
            }elseif($_POST['Status'] == ''){
                echo "กรุณาเลือกสถานะครุภัณฑ์";
            }else{
                $stmt2 = $pdo->prepare("UPDATE Item SET Location=?, Status=? WHERE ItemID = ? ");
                $stmt2->bindParam(1,$_POST['Location']);
                $stmt2->bindParam(2,$_POST['Status']);
                $stmt2->bindParam(3,$_POST['ItemID']);
                if($stmt2->execute()){     
                    echo "แก้ไขข้อมูลสำเร็จ<a href='detail.php?ItemTypeName=". $_POST['ItemTypeName'] ."'>ย้อนกลับ</a>";
                    //header("location: detail.php?ItemTypeName=". $_POST['ItemTypeName'].""); 
                }
        }
        }
		?>
        </div>
        
  </div>
 		

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->

<!-- jQuery -->
<script src="plugins/jquery/jquery.min.js"></script>
<!-- jQuery UI 1.11.4 -->
<script src="plugins/jquery-ui/jquery-ui.min.js"></script>
<!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
<script>
  $.widget.bridge('uibutton', $.ui.button)
</script>
<!-- Bootstrap 4 -->
<script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- ChartJS -->
<script src="plugins/chart.js/Chart.min.js"></script>
<!-- Sparkline -->
<script src="plugins/sparklines/sparkline.js"></script>
<!-- JQVMap -->
<script src="plugins/jqvmap/jquery.vmap.min.js"></script>
<script src="plugins/jqvmap/maps/jquery.vmap.usa.js"></script>
<!-- jQuery Knob Chart -->
<script src="plugins/jquery-knob/jquery.knob.min.js"></script>
<!-- daterangepicker -->
<script src="plugins/moment/moment.min.js"></script>
<script src="plugins/daterangepicker/daterangepicker.js"></script>
<!-- Tempusdominus Bootstrap 4 -->
<script src="plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js"></script>
<!-- Summernote -->
<script src="plugins/summernote/summernote-bs4.min.js"></script>
<!-- overlayScrollbars -->
<script src="plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js"></script>
<!-- AdminLTE App -->
<script src="dist/js/adminlte.js"></script>
<!-- AdminLTE dashboard demo (This is only for demo purposes) -->
<script src="dist/js/pages/dashboard.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="dist/js/demo.js"></script>

</body>
</html>
